/**
 * SCORM 1.2 API Wrapper
 * Module 2: AI-Driven Boilerplate & Dependency Injection
 *
 * Handles: LMSInitialize, LMSFinish, LMSGetValue, LMSSetValue,
 *          LMSCommit, LMSGetLastError, LMSGetErrorString, LMSGetDiagnostic
 *
 * Tracks:
 *   - cmi.core.lesson_status  (not attempted / incomplete / completed / passed / failed)
 *   - cmi.core.score.raw      (0–100)
 *   - cmi.core.score.min      (0)
 *   - cmi.core.score.max      (100)
 *   - cmi.core.session_time   (HH:MM:SS)
 *   - cmi.suspend_data        (JSON progress blob — screen index, quiz answers, checklist)
 *   - cmi.core.lesson_location (current screen index as string)
 *   - cmi.core.student_name   (read from LMS)
 *   - cmi.core.student_id     (read from LMS)
 */

var SCORM = (function () {

  // ── Internal state ──────────────────────────────────────────────────────────
  var _api        = null;
  var _initialized = false;
  var _finished   = false;
  var _startTime  = null;   // Date when session began
  var _lastError  = "0";

  // Local data model mirror
  var _data = {
    "cmi.core.lesson_status"   : "incomplete",
    "cmi.core.score.raw"       : "",
    "cmi.core.score.min"       : "0",
    "cmi.core.score.max"       : "100",
    "cmi.core.session_time"    : "00:00:00",
    "cmi.suspend_data"         : "",
    "cmi.core.lesson_location" : "0",
    "cmi.core.student_name"    : "",
    "cmi.core.student_id"      : "",
    "cmi.core.exit"            : ""
  };

  // ── API Discovery ────────────────────────────────────────────────────────────
  function _findAPI(win) {
    var attempts = 0;
    while (win.API == null && win.parent != null && win.parent != win) {
      attempts++;
      if (attempts > 500) { return null; }
      win = win.parent;
    }
    return win.API || null;
  }

  function _getAPI() {
    var api = _findAPI(window);
    if (api == null && window.opener != null) {
      api = _findAPI(window.opener);
    }
    return api;
  }

  // ── Utility: elapsed time → HH:MM:SS ────────────────────────────────────────
  function _elapsedTime() {
    if (!_startTime) { return "00:00:00"; }
    var secs = Math.floor((new Date() - _startTime) / 1000);
    var h = Math.floor(secs / 3600);
    var m = Math.floor((secs % 3600) / 60);
    var s = secs % 60;
    return (h < 10 ? "0" : "") + h + ":" +
           (m < 10 ? "0" : "") + m + ":" +
           (s < 10 ? "0" : "") + s;
  }

  // ── Public API ───────────────────────────────────────────────────────────────
  function initialize() {
    if (_initialized) { return true; }
    _api = _getAPI();
    if (_api == null) {
      console.warn("SCORM 1.2: No LMS API found. Running in standalone mode.");
      _initialized = true;
      _startTime = new Date();
      _tryRestoreLocalProgress();
      return false;
    }
    var result = _api.LMSInitialize("");
    if (result === "true" || result === true) {
      _initialized = true;
      _startTime = new Date();
      _lastError = "0";
      // Pull existing data from LMS
      _data["cmi.core.student_name"]    = _api.LMSGetValue("cmi.core.student_name") || "";
      _data["cmi.core.student_id"]      = _api.LMSGetValue("cmi.core.student_id")   || "";
      _data["cmi.core.lesson_status"]   = _api.LMSGetValue("cmi.core.lesson_status") || "not attempted";
      _data["cmi.suspend_data"]         = _api.LMSGetValue("cmi.suspend_data")        || "";
      _data["cmi.core.lesson_location"] = _api.LMSGetValue("cmi.core.lesson_location") || "0";
      console.log("SCORM 1.2: Initialized. Student:", _data["cmi.core.student_name"]);
      return true;
    } else {
      _lastError = _api.LMSGetLastError();
      console.error("SCORM 1.2: LMSInitialize failed. Error:", _lastError);
      return false;
    }
  }

  function finish() {
    if (!_initialized || _finished) { return true; }
    _finished = true;
    _data["cmi.core.session_time"] = _elapsedTime();
    if (_api == null) {
      // Standalone: save to localStorage
      _trySaveLocalProgress();
      return true;
    }
    _api.LMSSetValue("cmi.core.session_time", _data["cmi.core.session_time"]);
    _api.LMSSetValue("cmi.core.lesson_status", _data["cmi.core.lesson_status"]);
    if (_data["cmi.core.score.raw"] !== "") {
      _api.LMSSetValue("cmi.core.score.raw", _data["cmi.core.score.raw"]);
      _api.LMSSetValue("cmi.core.score.min", _data["cmi.core.score.min"]);
      _api.LMSSetValue("cmi.core.score.max", _data["cmi.core.score.max"]);
    }
    _api.LMSSetValue("cmi.suspend_data",         _data["cmi.suspend_data"]);
    _api.LMSSetValue("cmi.core.lesson_location", _data["cmi.core.lesson_location"]);
    _api.LMSSetValue("cmi.core.exit",            _data["cmi.core.exit"]);
    _api.LMSCommit("");
    var result = _api.LMSFinish("");
    console.log("SCORM 1.2: LMSFinish result:", result);
    return (result === "true" || result === true);
  }

  function getValue(key) {
    if (_api && _initialized) {
      return _api.LMSGetValue(key);
    }
    return _data[key] || "";
  }

  function setValue(key, value) {
    _data[key] = String(value);
    if (_api && _initialized && !_finished) {
      var result = _api.LMSSetValue(key, String(value));
      if (result !== "true" && result !== true) {
        _lastError = _api.LMSGetLastError();
        console.warn("SCORM 1.2: LMSSetValue failed for", key, "Error:", _lastError);
      }
      return (result === "true" || result === true);
    }
    return true;
  }

  function commit() {
    if (_api && _initialized && !_finished) {
      _api.LMSCommit("");
    }
  }

  // ── Progress helpers (called by course logic) ────────────────────────────────

  /**
   * Update lesson status.
   * @param {string} status - "not attempted" | "incomplete" | "completed" | "passed" | "failed"
   */
  function setStatus(status) {
    var valid = ["not attempted","incomplete","completed","passed","failed","browsed"];
    if (valid.indexOf(status) === -1) { status = "incomplete"; }
    setValue("cmi.core.lesson_status", status);
  }

  /**
   * Set raw score (0–100). Automatically sets passed/failed if mastery is defined.
   * @param {number} raw     - Score 0–100
   * @param {number} mastery - Pass threshold (default 75)
   */
  function setScore(raw, mastery) {
    mastery = (mastery !== undefined) ? mastery : 75;
    raw = Math.round(Math.max(0, Math.min(100, raw)));
    setValue("cmi.core.score.raw", String(raw));
    setValue("cmi.core.score.min", "0");
    setValue("cmi.core.score.max", "100");
    var status = (raw >= mastery) ? "passed" : "failed";
    setStatus(status);
    commit();
  }

  /**
   * Save course progress as suspend_data JSON blob.
   * @param {object} progressObj - arbitrary progress data
   */
  function saveProgress(progressObj) {
    try {
      var json = JSON.stringify(progressObj);
      // SCORM 1.2 suspend_data max is 4096 chars — truncate gracefully
      if (json.length > 4000) {
        console.warn("SCORM 1.2: suspend_data near limit, trimming history.");
        if (progressObj.history) { progressObj.history = []; }
        json = JSON.stringify(progressObj);
      }
      setValue("cmi.suspend_data", json);
      setValue("cmi.core.lesson_location", String(progressObj.screen || 0));
      commit();
      _trySaveLocalProgress();
    } catch(e) {
      console.error("SCORM 1.2: saveProgress error:", e);
    }
  }

  /**
   * Restore previously saved suspend_data.
   * @returns {object|null}
   */
  function loadProgress() {
    var raw = getValue("cmi.suspend_data");
    if (!raw || raw === "") {
      return _tryRestoreLocalProgress();
    }
    try {
      return JSON.parse(raw);
    } catch(e) {
      return null;
    }
  }

  // ── Standalone / offline fallback (localStorage) ────────────────────────────
  var LS_KEY = "scorm_di_module2";

  function _trySaveLocalProgress() {
    try {
      var blob = {
        lesson_status:    _data["cmi.core.lesson_status"],
        score:            _data["cmi.core.score.raw"],
        lesson_location:  _data["cmi.core.lesson_location"],
        suspend_data:     _data["cmi.suspend_data"],
        saved_at:         new Date().toISOString()
      };
      localStorage.setItem(LS_KEY, JSON.stringify(blob));
    } catch(e) {}
  }

  function _tryRestoreLocalProgress() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (!raw) { return null; }
      var blob = JSON.parse(raw);
      if (blob.lesson_status)   { _data["cmi.core.lesson_status"]   = blob.lesson_status; }
      if (blob.score)           { _data["cmi.core.score.raw"]        = blob.score; }
      if (blob.lesson_location) { _data["cmi.core.lesson_location"]  = blob.lesson_location; }
      if (blob.suspend_data)    { _data["cmi.suspend_data"]          = blob.suspend_data; }
      if (blob.suspend_data) {
        try { return JSON.parse(blob.suspend_data); } catch(e) {}
      }
      return null;
    } catch(e) {
      return null;
    }
  }

  // ── Expose public interface ──────────────────────────────────────────────────
  return {
    initialize   : initialize,
    finish       : finish,
    getValue     : getValue,
    setValue     : setValue,
    commit       : commit,
    setStatus    : setStatus,
    setScore     : setScore,
    saveProgress : saveProgress,
    loadProgress : loadProgress,
    getStudentName: function() { return _data["cmi.core.student_name"]; },
    getStudentId  : function() { return _data["cmi.core.student_id"]; }
  };

})();

// ── Auto-finish on page unload ───────────────────────────────────────────────
window.addEventListener("beforeunload", function() {
  if (SCORM) { SCORM.finish(); }
});
